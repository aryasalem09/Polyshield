// HTTP client for the Polyshield control plane. Every call is an outbound
// POST to /api/runner with the pairing token as a bearer — the runner never
// listens on anything.
import { hostname } from "node:os";

export class ControlPlaneError extends Error {
  constructor(message, status) {
    super(message);
    this.status = status;
  }
}

export class ControlPlane {
  constructor(baseUrl, token, version) {
    this.endpoint = new URL("/api/runner", baseUrl).toString();
    this.token = token;
    this.version = version;
  }

  async #post(body) {
    let res;
    try {
      res = await fetch(this.endpoint, {
        method: "POST",
        headers: {
          "content-type": "application/json",
          authorization: `Bearer ${this.token}`,
        },
        body: JSON.stringify(body),
        signal: AbortSignal.timeout(30_000),
      });
    } catch (err) {
      throw new ControlPlaneError(
        `Could not reach the Polyshield control plane at ${new URL(this.endpoint).host}: ${err?.message ?? err}`,
      );
    }
    const text = await res.text();
    let json = {};
    try {
      json = text ? JSON.parse(text) : {};
    } catch {
      throw new ControlPlaneError(`Control plane returned non-JSON (HTTP ${res.status}).`, res.status);
    }
    if (!res.ok) {
      throw new ControlPlaneError(json.error ?? `Control plane error (HTTP ${res.status}).`, res.status);
    }
    return json;
  }

  /**
   * Heartbeat + report per-server state, receive the stdio server configs
   * (env secrets are released by the control plane only to a paired runner).
   * reports: [{serverId, status?, error?, tools?}]
   */
  async sync(reports = []) {
    return this.#post({
      op: "sync",
      hostname: hostname(),
      version: this.version,
      servers: reports,
    });
  }

  /** Claim up to `max` pending jobs (call | dryrun | restore). */
  async claim(max = 5) {
    return this.#post({ op: "claim", max });
  }

  /** Deliver a job result (or error). `kind` lets the server store dry-run
   *  previews as-is instead of coercing them to a tool-result shape. */
  async complete(jobId, result, error, kind = "call") {
    return this.#post({ op: "complete", jobId, result, error, kind });
  }

  /** Register a snapshot taken before a destructive call (undo point). */
  async reportSnapshot({ serverId, jobId, label, scopePath, ref, snapshotKind, bytes }) {
    return this.#post({
      op: "snapshot",
      serverId,
      jobId,
      label,
      scopePath,
      ref,
      snapshotKind,
      bytes,
    });
  }

  /** Report the outcome of a restore job back onto the snapshot row. */
  async markSnapshotRestored(snapshotId, ok) {
    return this.#post({ op: "snapshot_restored", snapshotId, ok });
  }
}
